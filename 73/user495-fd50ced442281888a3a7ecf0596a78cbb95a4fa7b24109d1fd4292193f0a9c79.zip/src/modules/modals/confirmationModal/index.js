export { setConfirmationModal, unsetConfirmationModal } from "./model/confirmationModalSllice"
export { Container as ConfirmationModal } from './ui/Layout/Container'
export { default as confirmationModalSlice } from './model/confirmationModalSllice'