export { default as categoriesSlice } from './categoriesSlice'
export { categoriesAPI } from './categoriesAPI'
export { addNewCustomCategory, editCustomCategory, deleteCategoryActions } from './categoriesSlice'