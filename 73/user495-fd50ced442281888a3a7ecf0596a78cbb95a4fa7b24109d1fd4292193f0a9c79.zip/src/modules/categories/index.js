export { Container as CategoriesModule } from './ui/Layout/Container'
export { categoriesSlice, categoriesAPI } from './model'