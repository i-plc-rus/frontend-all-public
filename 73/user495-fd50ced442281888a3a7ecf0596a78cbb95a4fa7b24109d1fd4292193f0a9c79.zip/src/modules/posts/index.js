export { postsSlice, postsAPI, resetPostList, getPostsList } from './model'
export { Container as PostsModule } from './ui/Layout/Container'