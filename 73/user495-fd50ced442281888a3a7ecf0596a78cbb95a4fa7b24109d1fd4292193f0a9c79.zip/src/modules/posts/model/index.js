export { default as postsSlice } from './postsSlice'
export { postsAPI, useGetPostsQuery } from './postsAPI'
export { getPostsList, resetPostList, deletePost, updatePostActions } from './postsSlice'
