import React from 'react'
import style from './Layout.module.sass'

export const Layout = () => {
    return(
        <div className={style.container}>
            <div className={style.preloader}>
            </div>
        </div>
    )
}