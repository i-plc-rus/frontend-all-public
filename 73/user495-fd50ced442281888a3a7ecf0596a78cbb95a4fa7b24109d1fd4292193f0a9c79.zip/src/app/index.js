export { appAPI, appSlice, checkAuthorization, setCurrentTheme } from './model'
export { App } from './App'